<h1>hell {{$name}}</h1>
<p>please use this link for verify your account</p>
<a href={{$link}}>{{$link}}</a>
